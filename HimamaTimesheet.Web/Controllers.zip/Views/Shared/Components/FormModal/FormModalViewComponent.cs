﻿using Microsoft.AspNetCore.Mvc;

namespace HimamaTimesheet.Web.Views.Shared.Components.FormModal
{
    public class FormModalViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}