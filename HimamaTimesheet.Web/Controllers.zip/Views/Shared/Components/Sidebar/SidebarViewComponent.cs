﻿using Microsoft.AspNetCore.Mvc;

namespace HimamaTimesheet.Web.Views.Shared.Components.Sidebar
{
    public class SidebarViewComponent : ViewComponent
    {
        public IViewComponentResult Invoke()
        {
            return View();
        }
    }
}