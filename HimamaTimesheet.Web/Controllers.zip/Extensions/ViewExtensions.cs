﻿namespace HimamaTimesheet.Web.Extensions
{
    public static class ViewExtensions
    {
    }
}